# Authentication System - Secure Login/Register Dashboard

A full-stack authentication system built with Node.js and Express, featuring secure password hashing, JWT-based session management, and a modern, professional frontend interface.

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Running the Project](#running-the-project)
- [Usage](#usage)
- [API Endpoints](#api-endpoints)
- [Security Features](#security-features)
- [File Structure](#file-structure)
- [Environment Variables](#environment-variables)
- [Troubleshooting](#troubleshooting)

## 🎯 Overview

This project implements a secure authentication system with:
- User registration with name, email, and password
- Secure login functionality
- Protected dashboard accessible only after authentication
- Modern, responsive frontend interface
- JWT tokens stored in HTTP-only cookies
- Bcrypt password hashing

## ✨ Features

- **User Registration**: Create new accounts with full name, email, and password
- **User Login**: Secure authentication with email and password
- **Protected Dashboard**: Personalized welcome message after successful login
- **Session Management**: JWT tokens stored in HTTP-only cookies
- **Password Security**: Bcrypt hashing with salt rounds
- **Responsive Design**: Modern UI that works on desktop and mobile devices
- **Error Handling**: User-friendly error messages for all operations

## 🛠 Tech Stack

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **bcryptjs** - Password hashing
- **jsonwebtoken** - JWT token generation and verification
- **cookie-parser** - Cookie management
- **uuid** - Unique user ID generation

### Frontend
- **HTML5** - Structure
- **CSS3** - Styling with modern design patterns
- **Vanilla JavaScript** - Client-side logic

### Data Storage
- **JSON File** (`users.json`) - User data storage (for demo purposes)

## 📁 Project Structure

```
ANURAG/
├── middleware/
│   └── auth.js          # JWT authentication middleware
├── routes/
│   └── auth.js          # Authentication routes (register, login, logout)
├── public/
│   ├── index.html       # Frontend HTML
│   ├── styles.css       # Frontend styles
│   └── app.js           # Frontend JavaScript
├── server.js            # Express server entry point
├── users.json           # User data storage (auto-generated)
├── package.json         # Dependencies and scripts
└── README.md            # This file
```

## 📋 Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js** (v14 or higher) - [Download here](https://nodejs.org/)
- **npm** (comes with Node.js) - Package manager
- A code editor (VS Code, Sublime Text, etc.)
- A modern web browser (Chrome, Firefox, Edge, etc.)

## 🚀 Installation

### Step 1: Clone or Navigate to Project Directory

If you have the project files, navigate to the project directory:

```bash
cd ANURAG
```

### Step 2: Install Dependencies

Install all required npm packages:

```bash
npm install
```

This will install the following dependencies:
- `express` - Web framework
- `bcryptjs` - Password hashing
- `jsonwebtoken` - JWT tokens
- `cookie-parser` - Cookie handling
- `body-parser` - Request body parsing
- `uuid` - Unique ID generation
- `nodemon` - Development tool (dev dependency)

### Step 3: Verify Installation

Check that `node_modules` folder was created and `package.json` exists:

```bash
ls node_modules
```

## ▶️ Running the Project

### Development Mode (with auto-reload)

For development with automatic server restart on file changes:

```bash
npm run dev
```

**Note**: Requires `nodemon` to be installed. If not installed, use:
```bash
npm install -g nodemon
```

### Production Mode

Start the server:

```bash
npm start
```

The server will start on `http://localhost:3000` by default.

You should see:
```
Server running on http://localhost:3000
```

### Access the Application

Open your web browser and navigate to:

```
http://localhost:3000
```

## 📖 Usage

### 1. Register a New User

1. Open the application in your browser
2. Click on the **"Register"** tab
3. Fill in the form:
   - **Full name**: Your name (e.g., "John Doe")
   - **Email**: Your email address (e.g., "john@example.com")
   - **Password**: A secure password (minimum 6 characters)
4. Click **"Sign up"**
5. You'll see a success message and be redirected to the login form

### 2. Login

1. Click on the **"Login"** tab (or it may already be active)
2. Enter your registered email and password
3. Click **"Login"**
4. Upon successful login, you'll be redirected to the dashboard
5. The dashboard will display: **"Welcome to the dashboard, [Your Name]"**

### 3. Access Protected Dashboard

- The dashboard is automatically displayed after successful login
- It shows a personalized welcome message with your name
- The dashboard is protected and requires authentication

### 4. Logout

1. Click the **"Logout"** button in the top-right corner
2. You'll be logged out and returned to the login/register page

## 🔌 API Endpoints

### Register User

**Endpoint**: `POST /api/register`

**Request Body**:
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "securepassword123"
}
```

**Success Response** (201):
```json
{
  "message": "Registered"
}
```

**Error Responses**:
- `400` - Missing required fields
- `409` - Email already registered

**Example using curl**:
```bash
curl -X POST http://localhost:3000/api/register \
  -H "Content-Type: application/json" \
  -d '{"name":"John Doe","email":"john@example.com","password":"password123"}'
```

### Login

**Endpoint**: `POST /api/login`

**Request Body**:
```json
{
  "email": "john@example.com",
  "password": "securepassword123"
}
```

**Success Response** (200):
```json
{
  "message": "Logged in"
}
```

**Note**: Sets an HTTP-only cookie named `token` containing the JWT.

**Error Responses**:
- `400` - Missing email or password
- `401` - Invalid credentials

**Example using curl**:
```bash
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"email":"john@example.com","password":"password123"}' \
  -c cookies.txt
```

### Logout

**Endpoint**: `POST /api/logout`

**Success Response** (200):
```json
{
  "message": "Logged out"
}
```

**Note**: Clears the authentication cookie.

**Example using curl**:
```bash
curl -X POST http://localhost:3000/api/logout \
  -b cookies.txt
```

### Get Dashboard (Protected)

**Endpoint**: `GET /dashboard`

**Headers**: Requires authentication cookie

**Success Response** (200):
```json
{
  "message": "Welcome to the dashboard, John Doe"
}
```

**Error Responses**:
- `401` - Unauthorized (no valid token)

**Example using curl**:
```bash
curl http://localhost:3000/dashboard \
  -b cookies.txt
```

## 🔒 Security Features

### Password Security
- **Bcrypt Hashing**: Passwords are hashed using bcrypt with 10 salt rounds
- **Never Stored in Plain Text**: Passwords are never stored or transmitted in plain text

### Session Management
- **JWT Tokens**: Secure JSON Web Tokens for session management
- **HTTP-Only Cookies**: Tokens stored in HTTP-only cookies (not accessible via JavaScript)
- **Token Expiration**: Tokens expire after 1 hour
- **SameSite Protection**: Cookies use `SameSite: lax` to prevent CSRF attacks

### Authentication Middleware
- **Protected Routes**: Dashboard route is protected by authentication middleware
- **Token Verification**: Every protected request verifies the JWT token
- **Automatic Logout**: Invalid or expired tokens result in automatic logout

### Production Recommendations
- Set `JWT_SECRET` environment variable to a strong, random secret
- Enable `secure: true` in cookie settings when using HTTPS
- Use a proper database (PostgreSQL, MongoDB) instead of JSON file
- Implement rate limiting to prevent brute force attacks
- Add email verification for registration
- Implement password reset functionality

## 📂 File Structure Details

### Backend Files

**`server.js`**
- Main Express server file
- Configures middleware (body-parser, cookie-parser)
- Serves static frontend files
- Defines routes and protected endpoints
- Starts the server on port 3000

**`routes/auth.js`**
- Handles `/api/register` endpoint
- Handles `/api/login` endpoint
- Handles `/api/logout` endpoint
- Manages user data in `users.json`
- Generates JWT tokens
- Sets authentication cookies

**`middleware/auth.js`**
- Authentication middleware
- Verifies JWT tokens from cookies
- Attaches user data to request object
- Protects routes from unauthorized access

### Frontend Files

**`public/index.html`**
- Main HTML structure
- Login and Register forms
- Dashboard section
- Tab navigation interface

**`public/styles.css`**
- Modern, professional styling
- Responsive design for mobile and desktop
- Clean color scheme with blue/green accents
- Smooth transitions and animations

**`public/app.js`**
- Client-side JavaScript logic
- Form submission handling
- API communication
- Dashboard loading
- Tab switching functionality
- Error message display

### Data Files

**`users.json`**
- Stores user data (auto-generated)
- Format:
```json
[
  {
    "id": "uuid",
    "name": "John Doe",
    "email": "john@example.com",
    "password": "hashed_password"
  }
]
```

## 🌍 Environment Variables

Create a `.env` file in the root directory (optional for development):

```env
PORT=3000
JWT_SECRET=your_super_secret_key_here_change_in_production
```

**Note**: In production, always use a strong, random `JWT_SECRET`. Never commit secrets to version control.

## 🐛 Troubleshooting

### Server won't start

**Problem**: `Error: Cannot find module 'express'`

**Solution**: Install dependencies:
```bash
npm install
```

### Port already in use

**Problem**: `Error: listen EADDRINUSE: address already in use :::3000`

**Solution**: 
1. Change the port in `server.js` or use environment variable:
```bash
PORT=3001 npm start
```
2. Or stop the process using port 3000

### Cannot access dashboard after login

**Problem**: Dashboard shows "Unauthorized" error

**Solution**:
1. Check browser console for errors
2. Ensure cookies are enabled in your browser
3. Verify the JWT_SECRET matches between server and middleware
4. Clear browser cookies and try logging in again

### Registration fails

**Problem**: "Email already registered" error

**Solution**: 
- Use a different email address
- Or delete `users.json` to reset all users (development only)

### Frontend not loading

**Problem**: Blank page or 404 errors

**Solution**:
1. Verify `public` folder exists with `index.html`, `styles.css`, and `app.js`
2. Check server console for errors
3. Ensure server is running on correct port
4. Clear browser cache and hard refresh (Ctrl+F5)

### Password validation issues

**Problem**: Password requirements not working

**Solution**:
- Ensure password is at least 6 characters long
- Check browser console for validation errors

## 📝 Development Commands

### Install dependencies
```bash
npm install
```

### Start server (production)
```bash
npm start
```

### Start server (development with auto-reload)
```bash
npm run dev
```

### Check Node.js version
```bash
node --version
```

### Check npm version
```bash
npm --version
```

## 🎓 Learning Resources

- [Express.js Documentation](https://expressjs.com/)
- [JWT.io](https://jwt.io/) - Learn about JSON Web Tokens
- [Bcrypt Documentation](https://www.npmjs.com/package/bcryptjs)
- [MDN Web Docs](https://developer.mozilla.org/) - Frontend development

## 📄 License

This project is for educational purposes. Feel free to use and modify as needed.

## 👤 Author

Created as part of the Authentication System task.

---

**Happy Coding! 🚀**
