const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const tabs = document.querySelectorAll('.tab');
const tabContents = document.querySelectorAll('.tab-content');
const authMessage = document.getElementById('authMessage');
const dashboardSection = document.getElementById('dashboardSection');
const authSection = document.getElementById('authSection');
const dashboardContent = document.getElementById('dashboardContent');
const logoutBtn = document.getElementById('logoutBtn');

function setActiveTab(name) {
  tabs.forEach((tab) => {
    tab.classList.toggle('active', tab.dataset.tab === name);
  });
  tabContents.forEach((panel) => {
    panel.classList.toggle('active', panel.id === `${name}Tab`);
  });
  clearMessage();
}

tabs.forEach((tab) => {
  tab.addEventListener('click', () => setActiveTab(tab.dataset.tab));
});

function showMessage(type, text) {
  authMessage.classList.remove('hidden', 'error', 'success');
  authMessage.classList.add(type === 'error' ? 'error' : 'success');
  authMessage.textContent = text;
}

function clearMessage() {
  authMessage.classList.add('hidden');
  authMessage.textContent = '';
}

async function apiRequest(path, options = {}) {
  const res = await fetch(path, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    credentials: 'include',
    ...options,
  });

  const isJson = res.headers.get('content-type')?.includes('application/json');
  const data = isJson ? await res.json().catch(() => ({})) : {};

  if (!res.ok) {
    const msg = data.error || data.message || `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearMessage();

  const formData = new FormData(loginForm);
  const payload = {
    email: formData.get('email')?.trim(),
    password: formData.get('password'),
  };

  try {
    await apiRequest('/api/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    showMessage('success', 'Logged in successfully. Loading dashboard…');
    await loadDashboard();
  } catch (err) {
    showMessage('error', err.message);
  }
});

registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearMessage();

  const formData = new FormData(registerForm);
  const payload = {
    name: formData.get('name')?.trim(),
    email: formData.get('email')?.trim(),
    password: formData.get('password'),
  };

  try {
    await apiRequest('/api/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    showMessage('success', 'Registered successfully. You can now login.');
    setActiveTab('login');
    loginForm.email.value = payload.email;
    loginForm.password.value = '';
  } catch (err) {
    showMessage('error', err.message);
  }
});

async function loadDashboard() {
  try {
    const data = await apiRequest('/dashboard');
    dashboardContent.textContent = data.message || 'You are logged in.';
    dashboardSection.classList.remove('hidden');
    authSection.classList.add('hidden');
    logoutBtn.classList.remove('hidden');
  } catch (err) {
    // If unauthorized, keep user on auth forms
    dashboardSection.classList.add('hidden');
    authSection.classList.remove('hidden');
    logoutBtn.classList.add('hidden');
  }
}

logoutBtn.addEventListener('click', async () => {
  try {
    await apiRequest('/api/logout', { method: 'POST' });
  } catch {
    // ignore errors on logout
  } finally {
    dashboardSection.classList.add('hidden');
    authSection.classList.remove('hidden');
    logoutBtn.classList.add('hidden');
    clearMessage();
    showMessage('success', 'You have been logged out.');
  }
});

// Try to load dashboard on first load (if cookie already exists)
loadDashboard();


