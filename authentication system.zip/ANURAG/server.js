const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const path = require('path');
const authRoutes = require('./routes/auth');
const authMiddleware = require('./middleware/auth');

const app = express();
app.use(bodyParser.json());
app.use(cookieParser());

// Serve static frontend
const publicPath = path.join(__dirname, 'public');
app.use(express.static(publicPath));

app.use('/api', authRoutes);

// Protected dashboard API for frontend
app.get('/dashboard', authMiddleware, (req, res) => {
  const displayName = req.user.name || req.user.email;
  res.json({ message: `Welcome to the dashboard, ${displayName}` });
});

// Fallback to index.html for any non-API route (supports refreshing)
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) {
    return next();
  }
  res.sendFile(path.join(publicPath, 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
